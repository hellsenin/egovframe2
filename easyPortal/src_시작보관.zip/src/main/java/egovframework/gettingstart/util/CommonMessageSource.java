package egovframework.gettingstart.util;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

public class CommonMessageSource extends ReloadableResourceBundleMessageSource implements MessageSource {
    private ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource;

    /**
     * getReloadableResourceBundleMessageSource()
     * 
     * @param reloadableResourceBundleMessageSource - resource MessageSource
     * @return ReloadableResourceBundleMessageSource
     */
    public void setReloadableResourceBundleMessageSource(ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource) {
    	this.reloadableResourceBundleMessageSource = reloadableResourceBundleMessageSource;
    }

    /**
     * getReloadableResourceBundleMessageSource()
     * 
     * @return ReloadableResourceBundleMessageSource
     */
    public ReloadableResourceBundleMessageSource getReloadableResourceBundleMessageSource() {
    	return reloadableResourceBundleMessageSource;
    }

    /**
     * 정의된 메세지 조회
     * 
     * @param code - 메세지 코드
     * @return String
     */
    public String getMessage(String code) {
    	return getReloadableResourceBundleMessageSource().getMessage(code, null, Locale.getDefault());
    }
    
    /**
     * 정의된 메세지 조회
     * 
     * @param code
     * @param args
     * @return
     */
    public String getMessage(String code, Object[] args) {
    	return getReloadableResourceBundleMessageSource().getMessage(code, args, Locale.getDefault());
    }
    
    public String getMessage(String code, Locale locale) {
    	return getReloadableResourceBundleMessageSource().getMessage(code, null, locale);
    }
}